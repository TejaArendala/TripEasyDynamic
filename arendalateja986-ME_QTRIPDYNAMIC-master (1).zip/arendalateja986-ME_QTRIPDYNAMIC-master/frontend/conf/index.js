
const config = { backendEndpoint: "https://tripeasy-dynamic.herokuapp.com" };

export default config;
